/*
 * @Description:
 * @version:
 * @Author: camus
 * @Date: 2021-03-08 09:49:58
 * @LastEditors: camus
 * @LastEditTime: 2021-03-08 10:02:17
 */
import echarts from 'echarts/lib/echarts'
import 'echarts/lib/chart/bar'
import 'echarts/lib/chart/line'
import 'echarts/lib/chart/pie'
// import 'echarts/lib/chart/rosePie'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/title'



export default echarts
