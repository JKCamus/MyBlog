export const CHANGE_PHOTO_LIST="home/CHANGE_PHOTO_LIST"

export const CHANGE_PHOTO_RENDER='home/CHANGE_PHOTO_RENDER'

export const heightType = {
  4: 3,
  3: 4,
  1: 1,
};
