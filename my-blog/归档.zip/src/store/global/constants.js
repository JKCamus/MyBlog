export const CHANGE_IS_MOBILE="global/CHANGE_IS_MOBILE"
export const LOGGED="global/LOGGED"
